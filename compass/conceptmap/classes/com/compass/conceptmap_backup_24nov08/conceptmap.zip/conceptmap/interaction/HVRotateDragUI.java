package com.compass.conceptmap.interaction;

import  com.compass.conceptmap.*;

import  java.awt.*;
import  java.awt.event.*;

/** HVRotateDragUI.  A combination of HVScrolling + rotating.
  * The graph is rotated, but the mouse is always kept on the same point
  * on the graph.
  *
  */
public class HVRotateDragUI extends TGAbstractDragUI implements TGPaintListener {

    HVScroll hvScroll;
    RotateScroll rotateScroll;
    Node mouseOverN;
    Node tempNode;

    TGPoint2D lastMousePos;
    double lastAngle;

  // ............

   /** Constructor with TGPanel <tt>tgp</tt>, HVScroll <tt>hvs</tt>
     * and a RotateScroll <tt>rs</tt>.
     */
    public HVRotateDragUI( TGPanel tgp, HVScroll hvs, RotateScroll rs ) {
        super(tgp);
        hvScroll = hvs;
        rotateScroll = rs;
    }

    double graphDist(double x, double y) {
        double adjx=(x-this.tgPanel.getDrawCenter().x);
        double adjy=(y-this.tgPanel.getDrawCenter().y);
        return Math.sqrt(adjx*adjx+adjy*adjy);
    }

    double getMouseAngle(double x, double y) {
        double adjx=(x-this.tgPanel.getDrawCenter().x);
        double adjy=(y-this.tgPanel.getDrawCenter().y);
        double ang = Math.atan(adjy/adjx);
        if (adjx==0)
            if(adjy>0) ang=Math.PI/2;
            else ang=-Math.PI/2;
        if(adjx<0) ang=ang+Math.PI;
        return ang;
    }

    public void preActivate() {
        tgPanel.addPaintListener(this);
    }

    public void preDeactivate() {
        tgPanel.removePaintListener(this);
        tgPanel.repaint();
    }

    public void mousePressed(MouseEvent e) {
        mouseOverN=tgPanel.getMouseOverN();
        if (mouseOverN!=null) {
            lastMousePos = new TGPoint2D(mouseOverN.drawx, mouseOverN.drawy);
            lastAngle = getMouseAngle(mouseOverN.drawx, mouseOverN.drawy);
        } else {
            tempNode=new Node(); //A hack, until lenses are better implemented
                                 //One should keep track of a real position on the graph
                                 //As opposed to having a temporary node do this task.
            tempNode.drawx = e.getX();
            tempNode.drawy = e.getY();
            tgPanel.updatePosFromDraw(tempNode);
            lastMousePos = new TGPoint2D(tempNode.drawx, tempNode.drawy);
            lastAngle = getMouseAngle(tempNode.drawx, tempNode.drawy);
        }
    }

    public void mouseReleased( MouseEvent e ) {}

    public void mouseDragged( MouseEvent e ) {
        double currX = e.getX();
        double currY = e.getY();
        double currDist = graphDist(currX,currY);

        if (mouseOverN!=null)
            lastAngle = getMouseAngle(mouseOverN.drawx, mouseOverN.drawy);
        else
            lastAngle = getMouseAngle(tempNode.drawx, tempNode.drawy);

        double currentAngle = getMouseAngle(currX, currY);
        if(lastAngle>currentAngle+Math.PI) currentAngle+=Math.PI*2; //Avoids bug at x==0
        else if(currentAngle>lastAngle+Math.PI) lastAngle+=Math.PI*2;

        if (currDist>60) rotateScroll.incrementRotateAngle((currentAngle-lastAngle));

        tgPanel.updateDrawPositions(); //Rotate, but don't redraw
        tgPanel.updateGraphSize(); //Just in case.  Mostly effects H+V Scrollbars

        if(tempNode!=null) tgPanel.updateDrawPos(tempNode); //The temporary node is not part of the graph,
                                                            //So it needs to be updated individually
        TGPoint2D lastMousePos;
        if(mouseOverN!=null)
            lastMousePos = new TGPoint2D(mouseOverN.drawx, mouseOverN.drawy);
        else
            lastMousePos = new TGPoint2D(tempNode.drawx, tempNode.drawy);

        TGPoint2D newPos = new TGPoint2D(currX,currY);

        if (!hvScroll.scrolling) hvScroll.scrollAtoB(lastMousePos, newPos); //Scroll the node to the mouse

        this.tgPanel.repaintAfterMove();

        if(tempNode!=null) tgPanel.updateDrawPos(tempNode); //The temporary node is not part of the graph,
                                                            //So it needs to be updated individually
    }

    public void paintFirst( Graphics g ) {
        TGPoint2D drawCenter = tgPanel.getDrawCenter();
        g.setColor(Color.lightGray);
        for(int i=0;i<16;i++) {
            double ang = Math.PI*2*i/16;
            double rayX = 1000*Math.cos(ang);
            double rayY = 1000*Math.sin(ang);
            g.drawLine((int) drawCenter.x, (int) drawCenter.y,
                       (int) (rayX+drawCenter.x),(int) (rayY+drawCenter.y));
            g.drawLine((int) drawCenter.x+1, (int) drawCenter.y,
                       (int) (rayX+drawCenter.x+1),(int) (rayY+drawCenter.y));
            g.drawLine((int) drawCenter.x, (int) drawCenter.y+1,
                       (int) (rayX+drawCenter.x),(int) (rayY+drawCenter.y+1));
            g.drawLine((int) drawCenter.x+1, (int) drawCenter.y+1,
                       (int) (rayX+drawCenter.x+1),(int) (rayY+drawCenter.y+1));
        }


        g.fillOval((int)drawCenter.x-60, (int) drawCenter.y-60, 120,120);
        g.setColor(tgPanel.BACK_COLOR);
        g.fillOval((int)drawCenter.x-58, (int) drawCenter.y-58, 116,116);

    }

    public void paintLast( Graphics g ) {}
    public void paintAfterEdges( Graphics g ) {}

} // end com.compass.conceptmap.interaction.HVRotateDragUI
