package com.compass.conceptmap.graphelements;

import com.compass.conceptmap.Node;

/** TGForEachNode: A dummy object for iterating through nodes
  */
public abstract class TGForEachNode {

    public abstract void forEachNode( Node n );

} // end com.compass.conceptmap.graphelements.TGForEachNode
