<?php
include "config.inc"; 
session_start();

echo $_SERVER['REMOTE_ADDR'];

?>
