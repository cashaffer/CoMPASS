<html>
<body>
<form method = "post" action = "run_sql.php">
<textarea name = "query" rows = 10 cols = 50></textarea>
<input type="submit" name="Submit" value="Submit">
</form>
</body>
</html>
