<?php
session_start();

if ($_SESSION['loginname'] == null)
	header("location:/compass/error_code.php?code=001"); 
//	echo $_SESSION['loginname'];
else {
	include "priority.php";
	$priority = new priority;
	if(!$priority->checkPage(4))
		header("location:/compass/error_code.php?code=004"); 
	else{		
		include "db_mysql_mt.inc"; 
			
		$db = new DB_Sql;
		
		$db->connect();
		//$sql="select idunit,name from UNIT order by name";
		$sql="select idunit,name from UNIT where idunit = 10 or idunit = 11 or idunit = 18 order by name";
		$db->query($sql);
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
</head>
<link rel="stylesheet" href="../css/compass.css" type="text/css" media=screen>
<body>
<center>
<p>&nbsp;</p>
  <p class="tabletitle">Select a Unit</p>
  <?
		while($db->next_record()){

		$unitname = $db->Record['name'];
		$parenpos = strpos($unitname,"(");   //GWS 1/3/08 - removing parentheses and indeces from titles
		if ($parenpos !== false) $unitname = substr($unitname,0,$parenpos);
  ?>
  <a href="explore.php?uid=<?=$db->Record['idunit']?>" class="f14b"><?=$unitname?></a> <p/>&nbsp;&nbsp;&nbsp;&nbsp;
  <?
	}
?>
<br>
<br>
<br>
<br>
Simulations:
<br>
<br>
<a href="../../sims/inclined_plane.php">Inclined Plane Simulation</a>
</center>
</body>
</html>
<?
	}
}
?>
