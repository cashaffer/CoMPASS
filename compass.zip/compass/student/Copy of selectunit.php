<?php
session_start();

if ($_SESSION['loginname'] == null)
	header("location:/compass/error_code.php?code=001"); 
//	echo $_SESSION['loginname'];
else {
	include "priority.php";
	$priority = new priority;
	if(!$priority->checkPage(1))
		header("location:/compass/error_code.php?code=004"); 
	else{		
		include "db_mysql_mt.inc"; 
			
		$db = new DB_Sql;
		
		$db->connect();
		//$sql="select idunit,name from UNIT order by name";
		// GWS - updated to display only the units for the current class
		$sql="select distinct unit.idunit, unit.name FROM unit, class_to_unit, takesclass, user where unit.idunit = class_to_unit.idunit and class_to_unit.idclass = takesclass.idclass and takesclass.idstudent and takesclass.idstudent = user.iduser and user.loginname = '" . $_SESSION['loginname'] . "' order by unit.name";
		$db->query($sql);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script language="JavaScript" type="text/JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
function orderby(column){
	MM_goToURL('self','../admin/conceptmap/tclist.php?searchname=<?= $searchname?>&orderby=%27%2Bcolum');
	return document.MM_returnValue;
}
function check(){
	str=document.form2.searchname.value;
	rtn = true;
	if(str == ""){
		alert("Please input name first!");
		form2.searchname.focus();
		rtn=false;
	}
	else if(str.length<=2){
		alert("String you input is too short!");
		form2.searchname.focus();
		rtn=false;
	}
	else
		rtn = true;
	return rtn;
}
</script>
</head>
<link rel="stylesheet" href="../css/compass.css" type="text/css" media=screen>
<body>
<center>
<p>&nbsp;</p>
  <p class="tabletitle">Select a Unit</p>
  <?
		while($db->next_record()){
			$unitname = $db->Record['name'];
			$parenpos = strpos($unitname,"(");   //GWS 1/3/08 - removing parentheses and indeces from titles
			if ($parenpos !== false) $unitname = substr($unitname,0,$parenpos);	 

?>
  
  <a href="explore.php?uid=<?=$db->Record['idunit']?>" class="f14b"><?=$unitname?></a> <p/>&nbsp;&nbsp;
  <?
	}
?>

<br>
<br>
<br>
<br>
Simulations:
<br>
<br>
<a href="../../sims/inclined_plane_2010.php">Inclined Plane Simulation</a>
<br><br>
<a href="../../sims/pulley.php">Pulley Simulation</a>
</center>
</body>
</html>
<?
	}
}
?>



