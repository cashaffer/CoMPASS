<?php
session_start();
if ($_SESSION['loginname'] == null)
	header("location:/compass/error_code.php?code=001"); 
else {
	include "priority.php";
	$priority = new priority;
	if(!$priority->checkPage(1))
		header("location:/compass/error_code.php?code=004"); 
}	

include "db_mysql_mt.inc"; 
include "config_mt.inc"; 
	
$db = new DB_Sql;

$db->connect();

$idexploration = $_SESSION['idexploration'];

		$sql = "select (UNIX_TIMESTAMP()-UNIX_TIMESTAMP(max(time))) timelength,max(time) lasttime,now() nowtime from LOGDATA where idexploration=".$idexploration;
		$db->query($sql);
		if($db->next_record()){
			$timelength=$db->Record['timelength'];
			$lasttime=$db->Record['lasttime'];
			$nowtime=$db->Record['nowtime'];
			if($timelength != null){
				$sql = "update LOGDATA set timelength=".$timelength.",endtime='".$nowtime."' where idexploration=".$idexploration." and time='".$lasttime."'";
				$db->query($sql);
			}
		}
session_unset();
session_destroy();
?>
<script language="JavaScript" type="text/JavaScript">
parent.document.location="http://compassproject.net";
</script>
