<?php
session_start();

if ($_SESSION['loginname'] == null)
	header("location:/compass/error_code.php?code=001"); 
//	echo $_SESSION['loginname'];
else {
	include "priority.php";
	$priority = new priority;
	if(!$priority->checkPage(1))
		header("location:/compass/error_code.php?code=004"); 
	else{		
		include "db_mysql.inc"; 
		include "tracer.inc";	
		include "showcontent_1.inc";	
		$db = new DB_Sql;
		
		$db->connect();

	  	$ids = array("uid" => 0, "suid" => 0, "tid" => 0, "cid" => 0, "eid" => 0, "source" => 0);
  		$uid=$_REQUEST['uid'];
  		if($uid !=null)
			$ids['uid'] = (int) $uid;
		$suid=$_REQUEST['suid'];
		if($suid != null) 
			$ids['suid'] = (int) $suid;
  		$tid=$_REQUEST['tid'];
  		if($tid !=null)
  			$ids['tid'] = (int) $tid;
  		$cid=$_REQUEST['cid'];
  		if($cid !=null)
  			$ids['cid'] = (int) $cid;
  		$eid=$_REQUEST['eid'];
  		if($eid !=null)
  			$ids['eid'] = (int) $eid;
  		$source=$_REQUEST['source'];
  		if($source !=null)
  			$ids['source'] = (int) $source;

//write log
  		$tracer = new tracer;
  		if($tracer->isNewAction($ids))
  			$tracer->updateLog($db);

// show contents 
		$sql="select idgrade from CLASS where idclass=".$_SESSION['idclass'];
		$db->query($sql);
		$db->next_record();
		$grade=$db->Record['idgrade'];
  		$showcontent = new showcontent_1($grade);
  		$showcontent->setids($ids);
  		$showcontent->getcontent($db);
  		$parts = $showcontent->getparts();
  		$detail = $showcontent->getdetail("content");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<link rel="stylesheet" href="../css/compass.css" type="text/css" media=screen>
<SCRIPT LANGUAGE="JavaScript">
function redirectmap(uid,tid,cid)
{ 
	parent.document.nav.location="nav.php?source=2&uid="+uid+"&tid="+tid+"&cid="+cid;
	parent.document.mapApplet.shareddata.setmap(uid,tid,cid,1);
//	self.location="nav.php?uid="+idunit;
}
</SCRIPT>
<body>
<h1><?=$showcontent->gettitle()?></h1>
<?
	if($detail != "")
		echo $detail;
	if($parts != null){
		echo "<p align=\"center\">";
		foreach ($parts as $key => $value )
			if($key!="content")
				echo "<a href=\"showcontent.php?part=".$key."\" class=\"tabletitle\">".$value."</a>&nbsp; &nbsp; &nbsp; &nbsp;";
		echo "</p>";
	}
?>
</body>
</html>
<?		  	
	}
}
?>
