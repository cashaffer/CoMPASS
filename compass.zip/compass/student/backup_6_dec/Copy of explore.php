<?
session_start();

if ($_SESSION['loginname'] == null)
	header("location:/compass/error_code.php?code=001"); 
//	echo $_SESSION['loginname'];
else {
	include "priority.php";
	$priority = new priority;
	if(!$priority->checkPage(1))
		header("location:/compass/error_code.php?code=004"); 
	else{	
		include "config.inc"; 		
		$uid = $_REQUEST['uid'];	
		$tid = $_REQUEST['tid'];	
		$cid = $_REQUEST['cid'];
		if($uid == null && $tid != null){
			include "db_mysql_mt.inc"; 		
			$db = new DB_Sql;
			$db->connect();
			$sql = "select idunit from TOPIC where idtopic=".$tid;
			$db->query($sql);
			if($db->next_record())
				$uid = $db->Record['idunit'];
		}
		if($uid == null)
			$uid="";
		if($tid == null)
			$tid="";
		if($cid == null)
			$cid="";
		
		$sub = "map.php?uid=".$uid."&tid=".$tid."&cid=".$cid;
		$sub1 = "nav.php?uid=".$uid."&tid=".$tid."&cid=".$cid;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Concept Maps</title>
<SCRIPT LANGUAGE="JavaScript">

function closewindow()
{ 
//	  window.location = "logout.php"
	//  if(basefrm.popup)
	//{
	// if(!basefrm.popup.closed)
	//    basefrm.popup.close();
	// }
	// window.location = "logout.asp"
}
function maximizeWin() { 
	if (window.screen)
	 { var aw = screen.availWidth; 
	   var ah = screen.availHeight; 
	   window.moveTo(0, 0);
	   window.resizeTo(aw, ah);
	 } 
} 

</script>
</head>
<body onLoad = "maximizeWin()">
<center>
  <table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td colspan="3"><IFRAME NAME="nav" width=100% height=150 marginwidth=0 marginheight=0 frameborder=0 scrolling=auto src="<?=$sub1?>"></IFRAME></td>
</tr>
<tr>
    <td width="520">
		        <applet code="com.compass.conceptmap.CompassApplet.class"
			ARCHIVE="compass.jar"

			codebase="/compass/conceptmap/classes"
			width="520" height="500" style="" name="mapApplet">
			<param name="textField" value="label"/>
			<param name="urlPrefix" value="http://<?=$_SERVER['SERVER_NAME']?>/compass/student/"/>
			<param name="concepts" value="http://<?=$_SERVER['SERVER_NAME']?>/compass/xmls/concepts.xml"/>
			<param name="relations" value="http://<?=$_SERVER['SERVER_NAME']?>/compass/xmls/relation.xml"/>
			<param name="examples" value="http://<?=$_SERVER['SERVER_NAME']?>/compass/xmls/examples.xml"/>
<?
	if($uid!=null){
?>
			<param name="focusUnit" value="<?=$uid?>"/>
<?
}
	if($tid!=null){
?>
			<param name="focusTopic" value="<?=$tid?>"/>
<?
}
	if($cid!=null){
?>
			<param name="focusConcept" value="<?=$cid?>"/>
<?
}
?>
			If you can read this text, the applet is not working. Perhaps you don't
			have the Java 1.4 (or later) web plug-in installed?
		</applet>
	</td>
	  <td width="20">&nbsp;</td>
	<td><br>
	<IFRAME NAME="content" width=100% height=520 marginwidth=0 marginheight=0 frameborder=0 scrolling=auto ></IFRAME>
	</td>
  </tr>
</table>
</center>
</body>
</html>
<?
	}
}
?>