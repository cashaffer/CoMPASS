<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"
xmlns:st1="urn:schemas-microsoft-com:office:smarttags"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 10">
<meta name=Originator content="Microsoft Word 10">
<link rel=File-List href="pretest_files/filelist.xml">
<link rel=Edit-Time-Data href="pretest_files/editdata.mso">
<link rel=OLE-Object-Data href="pretest_files/oledata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]-->
<title>PHYSICS FIESTA</title>
<o:SmartTagType namespaceuri="urn:schemas-microsoft-com:office:smarttags"
 name="date"/>
<o:SmartTagType namespaceuri="urn:schemas-microsoft-com:office:smarttags"
 name="City"/>
<o:SmartTagType namespaceuri="urn:schemas-microsoft-com:office:smarttags"
 name="place"/>
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>aditi</o:Author>
  <o:LastAuthor>cao2</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>11</o:TotalTime>
  <o:Created>2005-08-16T20:01:00Z</o:Created>
  <o:LastSaved>2005-08-16T20:01:00Z</o:LastSaved>
  <o:Pages>11</o:Pages>
  <o:Words>1081</o:Words>
  <o:Characters>6163</o:Characters>
  <o:Company> WCER</o:Company>
  <o:Lines>51</o:Lines>
  <o:Paragraphs>14</o:Paragraphs>
  <o:CharactersWithSpaces>7230</o:CharactersWithSpaces>
  <o:Version>10.6714</o:Version>
 </o:DocumentProperties>
 <o:CustomDocumentProperties>
  <o:_AdHocReviewCycleID dt:dt="float">81075962</o:_AdHocReviewCycleID>
  <o:_EmailSubject dt:dt="string">CoMPASS &#45;- Physics Fiesta, Other Materials, PI Mtg</o:_EmailSubject>
  <o:_AuthorEmail dt:dt="string">srebello@phys.ksu.edu</o:_AuthorEmail>
  <o:_AuthorEmailDisplayName dt:dt="string">Rebello, Sanjay</o:_AuthorEmailDisplayName>
  <o:_ReviewingToolsShownOnce dt:dt="string"></o:_ReviewingToolsShownOnce>
 </o:CustomDocumentProperties>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:FormsDesign/>
  <w:DrawingGridHorizontalSpacing>0.7 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>0.7 pt</w:DrawingGridVerticalSpacing>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
  </w:Compatibility>
  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>
 </w:WordDocument>
</xml><![endif]--><!--[if !mso]><object
 classid="clsid:38481807-CA0E-42D2-BF39-B33AF135CC4D" id=ieooui></object>
<style>
st1\:*{behavior:url(#ieooui) }
</style>
<![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:1627421319 -2147483648 8 0 66047 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-parent:"";
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-language:EN-US;}
p.MsoCommentText, li.MsoCommentText, div.MsoCommentText
	{mso-style-noshow:yes;
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-language:EN-US;}
span.MsoCommentReference
	{mso-style-noshow:yes;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;}
p
	{mso-margin-top-alt:auto;
	margin-right:0in;
	mso-margin-bottom-alt:auto;
	margin-left:0in;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-language:EN-US;}
p.MsoCommentSubject, li.MsoCommentSubject, div.MsoCommentSubject
	{mso-style-noshow:yes;
	mso-style-parent:"Comment Text";
	mso-style-next:"Comment Text";
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-language:EN-US;
	font-weight:bold;}
@page Section1
	{size:8.5in 11.0in;
	margin:1.0in 1.25in .5in 63.0pt;
	mso-header-margin:.5in;
	mso-footer-margin:.5in;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="2050">
  <o:colormenu v:ext="edit" fillcolor="#333" strokecolor="none"/>
 </o:shapedefaults></xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
  <o:regrouptable v:ext="edit">
   <o:entry new="1" old="0"/>
   <o:entry new="2" old="0"/>
   <o:entry new="3" old="0"/>
  </o:regrouptable>
 </o:shapelayout></xml><![endif]-->
</head>
<script Language="Javascript" Type="text/Javascript" >
<!--
function form1_validate(form1)
{
	var radioselected=false;                           
	for(i=0;i<form1.Q1.length;i++)
	{
		if(form1.Q1[i].checked)
		radioselected=true;
	}
	if(!radioselected)                                               
	{
		alert("enter your choice for Question 1");
		return (false);
	}		
	
	radioselected=false;                            
	for(i=0;i<form1.Q2a.length;i++)
	{
		if(form1.Q2a[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 2a");
		return (false);
	}		
	
	if (form1.Q2b.value=="")                                     
	{
       alert("enter  a value for Question 2b");
	form1.Q2b.focus();
	return(false);
        }
	
	radioselected=false;                            
	for(i=0;i<form1.Q3a.length;i++)
	{
		if(form1.Q3a[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 3a");
		return (false);
	}	
	if (form1.Q3b.value=="")                                     
	{
       alert("enter a value for Question 3b");
	form1.Q3b.focus();
	return(false);
        }	

	radioselected=false;                            
	for(i=0;i<form1.Q4a.length;i++)
	{
		if(form1.Q4a[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 4a");
		return (false);
	}		
	
	if (form1.Q4b.value=="")                                     
	{
       alert("enter  a value for Question 4b");
		form1.Q4b.focus();
		return(false);
    }
	
	radioselected=false;                           
	for(i=0;i<form1.Q5.length;i++)
	{
		if(form1.Q5[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 5");
		return (false);
	}

	radioselected=false;                            
	for(i=0;i<form1.Q6.length;i++)
	{
		if(form1.Q6[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 6");
		return (false);
	}	
	
	if (form1.Q7.value=="")                                     
	{
       alert("enter a value for Question 7");
		form1.Q7.focus();
		return(false);
    }

	radioselected=false;                            
	for(i=0;i<form1.Q8.length;i++)
	{
		if(form1.Q8[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 8");
		return (false);
	}
	
	radioselected=false;                            
	for(i=0;i<form1.Q9.length;i++)
	{
		if(form1.Q9[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 9");
		return (false);
	}
	
	radioselected=false;                           
	for(i=0;i<form1.Q10.length;i++)
	{
		if(form1.Q10[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 10");
		return (false);
	}	
	
	radioselected=false;                            
	for(i=0;i<form1.Q11.length;i++)
	{
		if(form1.Q11[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 11");
		return (false);
	}	<br>

	radioselected=false;                            
	for(i=0;i<form1.Q12.length;i++)
	{
		if(form1.Q12[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 12");
		return (false);
	}	
	
	radioselected=false;                            
	for(i=0;i<form1.Q13a.length;i++)
	{
		if(form1.Q13a[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 13a");
		return (false);
	}	
	if (form1.Q13b.value=="")                                     
	{
       alert("enter a value for Question 13b");
		form1.Q13b.focus();
		return(false);
    }

	radioselected=false;                            
	for(i=0;i<form1.Q14.length;i++)
	{
		if(form1.Q14[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 14");
		return (false);
	}	
	
	var radioselected=false;                            
	for(i=0;i<form1.Q15.length;i++)
	{
		if(form1.Q15[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 15");
		return (false);
	}	

	radioselected=false;                            
	for(i=0;i<form1.Q16.length;i++)
	{
		if(form1.Q16[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 16");
		return (false);
	}	

	radioselected=false;                            
	for(i=0;i<form1.Q17.length;i++)
	{
		if(form1.Q17[i].checked)
		radioselected=true;
	}
	if(!radioselected)
	{
		alert("enter your choice for Question 17");
		return (false);
	}	

	return(true);
}
//--></script>

<body lang=EN-US style='tab-interval:.5in'>

<div class=Section1>

<p align=center style='text-align:center'><strong><span style='font-size:18.0pt'>PHYSICS
FIESTA (Revised </span></strong><st1:date
Year="2005" Day="5" Month="8"><strong><span style='font-size:18.0pt'>08-05-2005</span></strong></st1:date><strong><span
style='font-size:18.0pt'>)</span></strong></p>

<p style='text-align:justify'><span style='font-family:Arial'>1. Type your name
in the box below. Click in the textbox to start writing. Select gender by
clicking in the circle next to the option.</span></p>

<p style='text-align:justify'><span style='font-family:Arial'>2. Answer the
questions by selecting the option that you think is the most appropriate. Some
questions require you to type your answer in the textbox. Click in the textbox
to start writing.</span></p>

<p style='text-align:justify'><span style='font-family:Arial'>3. When you
finish with all questions click the <em><span style='font-family:Arial'>Submit </span></em>button.
If you want to clear all the answers that you provided and start again click on
the <em><span style='font-family:Arial'>Reset</span></em> button.</span></p>

<p style='text-align:justify'><span style='font-family:Arial'>Note: You MUST
answer all the questions before you click the <em><span style='font-family:
Arial'>submit</span></em> button.</span></p>

<p align=center style='text-align:center'><strong>GOOD LUCK!!!</strong></p>

<form action="saveanswer.php" method="post"  onSubmit="return form1_validate(this);">
    <p style='text-align:justify'><strong>Name: 
      <INPUT TYPE="TEXT" NAME="Name">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Class: 
      <SELECT NAME="Class">
        <OPTION VALUE="Class 2">Class 1 
        <OPTION VALUE="Class 2">Class 2 
        <OPTION VALUE="Class 3">Class 3 
        <OPTION VALUE="Class 4">Class 4 
        <OPTION VALUE="Class 5">Class 5 
      </SELECT>
      </strong></p>
    <p style='text-align:justify'><strong>Teacher: </strong><strong><span
style='font-weight:normal'> 
      <SELECT NAME="Teacher">
        <OPTION SELECTED VALUE="Mrs. Gnesdilow">Mrs. Gnesdilow 
        <OPTION VALUE="Mrs. Mehalakes">Mrs. Mehalakes 
      </SELECT>
      </span>&nbsp; &nbsp; Gender: Female 
      <INPUT TYPE="radio" NAME="Gender" VALUE="1">
      &nbsp;&nbsp;Male </strong><strong><span style='font-weight:normal'> 
      <INPUT TYPE="radio" NAME="Gender" VALUE="2">
      </span></strong></p>
    <p style='text-align:justify'>&nbsp;</p>

<p style='text-align:justify'>1. When you bend your arm at the elbow, the 
      bone and muscles in your arm are acting as a system. What simple machine 
      does this system represent?</p>

<p><INPUT TYPE="radio" NAME="Q1" VALUE="1">Inclined plane <br>
<INPUT TYPE="radio" NAME="Q1" VALUE="2">Pulley <br>
<INPUT TYPE="radio" NAME="Q1" VALUE="3">Wedge <br>
<INPUT TYPE="radio" NAME="Q1" VALUE="4">Lever </p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
</span>

<p style='text-align:justify'>2a. Blocks A and B are shown below.</p>

<p style='text-align:justify'><!--[if mso & !supportInlineShapes & supportFields]><span
style='mso-element:field-begin;mso-field-lock:yes'></span><span
style='mso-spacerun:yes'>�</span>SHAPE<span style='mso-spacerun:yes'>�
</span>\* MERGEFORMAT <span style='mso-element:field-separator'></span><![endif]--><!--[if gte vml 1]><v:group
 id="_x0000_s1057" editas="canvas" style='width:283.5pt;height:93.9pt;
 mso-position-horizontal-relative:char;mso-position-vertical-relative:line'
 coordorigin="3821,1530" coordsize="4447,1473">
 <o:lock v:ext="edit" aspectratio="t"/>
 <v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75"
  o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
  <v:stroke joinstyle="miter"/>
  <v:formulas>
   <v:f eqn="if lineDrawn pixelLineWidth 0"/>
   <v:f eqn="sum @0 1 0"/>
   <v:f eqn="sum 0 0 @1"/>
   <v:f eqn="prod @2 1 2"/>
   <v:f eqn="prod @3 21600 pixelWidth"/>
   <v:f eqn="prod @3 21600 pixelHeight"/>
   <v:f eqn="sum @0 0 1"/>
   <v:f eqn="prod @6 1 2"/>
   <v:f eqn="prod @7 21600 pixelWidth"/>
   <v:f eqn="sum @8 21600 0"/>
   <v:f eqn="prod @7 21600 pixelHeight"/>
   <v:f eqn="sum @10 21600 0"/>
  </v:formulas>
  <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
  <o:lock v:ext="edit" aspectratio="t"/>
 </v:shapetype><v:shape id="_x0000_s1056" type="#_x0000_t75" style='position:absolute;
  left:3821;top:1530;width:4447;height:1473' o:preferrelative="f">
  <v:fill o:detectmouseclick="t"/>
  <v:path o:extrusionok="t" o:connecttype="none"/>
  <o:lock v:ext="edit" text="t"/>
 </v:shape><v:line id="_x0000_s1058" style='position:absolute' from="4103,2223"
  to="7892,2223" strokeweight="6pt"/>
 <v:shapetype id="_x0000_t5" coordsize="21600,21600" o:spt="5" adj="10800"
  path="m@0,l,21600r21600,xe">
  <v:stroke joinstyle="miter"/>
  <v:formulas>
   <v:f eqn="val #0"/>
   <v:f eqn="prod #0 1 2"/>
   <v:f eqn="sum @1 10800 0"/>
  </v:formulas>
  <v:path gradientshapeok="t" o:connecttype="custom" o:connectlocs="@0,0;@1,10800;0,21600;10800,21600;21600,21600;@2,10800"
   textboxrect="0,10800,10800,18000;5400,10800,16200,18000;10800,10800,21600,18000;0,7200,7200,21600;7200,7200,14400,21600;14400,7200,21600,21600"/>
  <v:handles>
   <v:h position="#0,topLeft" xrange="0,21600"/>
  </v:handles>
 </v:shapetype><v:shape id="_x0000_s1059" type="#_x0000_t5" style='position:absolute;
  left:5809;top:2259;width:376;height:517' fillcolor="silver"/>
 <v:rect id="_x0000_s1060" style='position:absolute;left:5103;top:1694;width:518;
  height:482' fillcolor="black">
  <v:fill src="pretest_files/image001.gif" o:title="Light downward diagonal"
   type="pattern"/>
 </v:rect><v:rect id="_x0000_s1061" style='position:absolute;left:7338;top:1682;
  width:518;height:483' fillcolor="black">
  <v:fill src="pretest_files/image002.gif" o:title="Light upward diagonal"
   type="pattern"/>
 </v:rect><v:shapetype id="_x0000_t202" coordsize="21600,21600" o:spt="202"
  path="m,l,21600r21600,l21600,xe">
  <v:stroke joinstyle="miter"/>
  <v:path gradientshapeok="t" o:connecttype="rect"/>
 </v:shapetype><v:shape id="_x0000_s1062" type="#_x0000_t202" style='position:absolute;
  left:5127;top:1741;width:459;height:365' filled="f" stroked="f">
  <v:textbox>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
     style='font-size:16.0pt'>A<o:p></o:p></span></b></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1063" type="#_x0000_t202" style='position:absolute;
  left:7351;top:1753;width:458;height:364' filled="f" stroked="f">
  <v:textbox>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
     style='font-size:16.0pt'>B<o:p></o:p></span></b></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><w:wrap type="none"/>
 <w:anchorlock/>
</v:group><![endif]--><![if !vml]><img width=378 height=125
src="pretest_files/image003.gif" v:shapes="_x0000_s1057 _x0000_s1056 _x0000_s1058 _x0000_s1059 _x0000_s1060 _x0000_s1061 _x0000_s1062 _x0000_s1063"><![endif]><!--[if mso & !supportInlineShapes & supportFields]><v:shape
 id="_x0000_i1025" type="#_x0000_t75" style='width:283.5pt;height:93.9pt'>
 <v:imagedata croptop="-65520f" cropbottom="65520f"/>
</v:shape><span style='mso-element:field-end'></span><![endif]--></p>

<p style='text-align:justify'>Which of the blocks is heavier?</p>

<p><INPUT TYPE="radio" NAME="Q2a" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q2a" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q2a" VALUE="3">A and B are equally heavy<br>
<INPUT TYPE="radio" NAME="Q2a" VALUE="4">Not enough information</p>

<p style='text-align:justify'>2b. Explain your reasoning.</p>

<p style='text-align:justify'><TEXTAREA ROWS="10" COLS="111" WRAP="VIRTUAL" NAME="Q2b"></TEXTAREA></p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'>3a. Machine A and Machine B are each designed to
clear a field. The table shows us how large an area each is cleared 1 hour and
how much gasoline each used. </p>

<table class=MsoNormalTable border=1 cellpadding=0 width="95%"
 style='width:95.54%;mso-cellspacing:1.5pt;border:outset 1.5pt'>
 <tr style='mso-yfti-irow:0;height:23.85pt'>
  <td style='padding:.75pt .75pt .75pt .75pt;height:23.85pt'>
  <p class=MsoNormal style='text-align:justify'><o:p>&nbsp;</o:p></p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:23.85pt'>
  <p class=MsoNormal style='text-align:justify'><b>Area of field cleared in 1
  hour<o:p></o:p></b></p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:23.85pt'>
  <p class=MsoNormal style='text-align:justify'><b>Gasoline used in 1 hour<o:p></o:p></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:27.25pt'>
  <td style='padding:.75pt .75pt .75pt .75pt;height:27.25pt'>
  <p class=MsoNormal style='text-align:justify'><b>Machine A<o:p></o:p></b></p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:27.25pt'>
  <p class=MsoNormal style='text-align:justify'>2 acres</p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:27.25pt'>
  <p class=MsoNormal style='text-align:justify'>3 gallons</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes;height:13.25pt'>
  <td style='padding:.75pt .75pt .75pt .75pt;height:13.25pt'>
  <p class=MsoNormal style='text-align:justify'><b>Machine B<o:p></o:p></b></p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:13.25pt'>
  <p class=MsoNormal style='text-align:justify'>3 acres</p>
  </td>
  <td style='padding:.75pt .75pt .75pt .75pt;height:13.25pt'>
  <p class=MsoNormal style='text-align:justify'>2 gallons</p>
  </td>
 </tr>
</table>

<p style='text-align:justify'>Which machine is more efficient in converting the
energy in gasoline to work? </p>

<p><INPUT TYPE="radio" NAME="Q3a" VALUE="1">Machine A <br>
<INPUT TYPE="radio" NAME="Q3a" VALUE="2">Machine B <br>
<INPUT TYPE="radio" NAME="Q3a" VALUE="3">Machine A and B are equally efficient<br>
<INPUT TYPE="radio" NAME="Q3a" VALUE="4">Not enough information</p>

<p style='text-align:justify'>3b. Explain your reasoning.</p>

<p style='text-align:justify'><TEXTAREA ROWS="10" COLS="111" WRAP="VIRTUAL" NAME="Q3b"></TEXTAREA></p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'>4a. A girl wants to play on a seesaw with her
little brother. Which picture shows the best way for the heavier girl to
balance her lighter brother? Choose the letter of the picture.</p>

<p style='text-align:justify'><!--[if gte vml 1]><v:shape id="_x0000_i1552"
 type="#_x0000_t75" alt="" style='width:6in;height:220.5pt'>
 <v:imagedata src="pretest_files/image004.gif" o:href="../posttest/physic5.gif"/>
</v:shape><![endif]--><![if !vml]><img width=576 height=294
src="pretest_files/image004.gif" v:shapes="_x0000_i1552"><![endif]></p>

<p style='text-align:justify'><INPUT TYPE="radio" NAME="Q4a" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q4a" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q4a" VALUE="3">C <br>
<INPUT TYPE="radio" NAME="Q4a" VALUE="4">D </p>

<p style='text-align:justify'>4b. Explain your reasoning.</p>

<p style='text-align:justify'><TEXTAREA ROWS="10" COLS="108" WRAP="VIRTUAL" NAME="Q4b"></TEXTAREA></p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='margin-top:0in;margin-right:0in;margin-bottom:0in;margin-left:.5in;
margin-bottom:.0001pt;text-align:justify;text-indent:-.25in'>5. A student pulls
four different objects horizontally across a table using a spring scale that measures
force. The data are shown below. On which one of them must she do the most
work?</p>

<table class=MsoNormalTable border=1 cellpadding=0 width="92%"
 style='width:92.9%;mso-cellspacing:1.5pt;margin-left:21.0pt;border:outset 1.5pt'>
 <tr style='mso-yfti-irow:0'>
  <td width="18%" style='width:18.48%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>Object<o:p></o:p></b></p>
  </td>
  <td width="34%" style='width:34.8%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>Spring Scale </b><st1:City><st1:place><b>Reading</b></st1:place></st1:City><b>
  (N)<o:p></o:p></b></p>
  </td>
  <td width="45%" style='width:45.32%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>Distance the object was
  pulled(m)<o:p></o:p></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width="18%" style='width:18.48%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>A<o:p></o:p></b></p>
  </td>
  <td width="34%" style='width:34.8%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>6.0</p>
  </td>
  <td width="45%" style='width:45.32%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>10</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width="18%" style='width:18.48%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>B<o:p></o:p></b></p>
  </td>
  <td width="34%" style='width:34.8%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>3.0</p>
  </td>
  <td width="45%" style='width:45.32%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>20</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes'>
  <td width="18%" style='width:18.48%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'><b>C<o:p></o:p></b></p>
  </td>
  <td width="34%" style='width:34.8%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>12.0</p>
  </td>
  <td width="45%" style='width:45.32%;padding:.75pt .75pt .75pt .75pt'>
  <p class=MsoNormal style='text-align:justify'>5</p>
  </td>
 </tr>
</table>

<p style='margin-left:.25in'><INPUT TYPE="radio" NAME="Q5" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q5" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q5" VALUE="3">C <br>
<INPUT TYPE="radio" NAME="Q5" VALUE="4">All the same<br>
<INPUT TYPE="radio" NAME="Q5" VALUE="5">Not enough information </p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>

<p style='margin-left:.25in;text-align:justify;text-indent:-.25in'><o:p>&nbsp;</o:p></p>

<p style='margin-left:.25in;text-align:justify;text-indent:-.25in'>6. Which of
the following machines changes neither the force nor the distance?</p>

<p><INPUT TYPE="radio" NAME="Q6" VALUE="1">Inclined Plane <br>
<INPUT TYPE="radio" NAME="Q6" VALUE="2">Wheel and axle <br>
<INPUT TYPE="radio" NAME="Q6" VALUE="3">Movable Pulley <br>
<INPUT TYPE="radio" NAME="Q6" VALUE="4">Fixed Pulley </p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'>7. What type of a simple machine is the blade of
a knife? Explain how it works.</p>

<p style='text-align:justify'><TEXTAREA ROWS="10" COLS="116" WRAP="VIRTUAL" NAME="Q7"></TEXTAREA></p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'>8. Which screw requires the least effort to turn?</p>

<p><INPUT TYPE="radio" NAME="Q8" VALUE="1">A wide screw whose threads are
close together<br>
<INPUT TYPE="radio" NAME="Q8" VALUE="2">A narrow screw whose threads are close
together<br>
<INPUT TYPE="radio" NAME="Q8" VALUE="3">A wide screw whose threads are far
apart<br>
<INPUT TYPE="radio" NAME="Q8" VALUE="4">A narrow screw whose threads are far
apart</p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'>9. The amount of work done on an object is found
by �</p>

<p><INPUT TYPE="radio" NAME="Q9" VALUE="1">multiplying the load and the effort
acting on the object <br>
<INPUT TYPE="radio" NAME="Q9" VALUE="2">dividing the load by the effort acting
on the object <br>
<INPUT TYPE="radio" NAME="Q9" VALUE="3">multiplying the effort acting on the
object and the distance traveled by the object<br>
<INPUT TYPE="radio" NAME="Q9" VALUE="4">dividing the effort acting on the
object by the distance traveled by the object<br style='mso-special-character:
line-break'>
<![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
<![endif]></p>

<p style='margin-left:.25in;text-indent:-.25in'>10. An example of a lever in
which the load is between the effort and the fulcrum (second class lever) is a �</p>

<p><INPUT TYPE="radio" NAME="Q10" VALUE="1">seesaw <br>
<INPUT TYPE="radio" NAME="Q10" VALUE="2">bottle opener <br>
<INPUT TYPE="radio" NAME="Q10" VALUE="3">shovel <br>
<INPUT TYPE="radio" NAME="Q10" VALUE="4">fishing pole </p>

    <p style='text-align:justify'><o:p>&nbsp;</o:p><span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
      </span> </p>

<p style='text-align:justify'>11. Which ramp would require the least effort to 
      ride up?</p>

<p style='text-align:justify'><!--[if mso & !supportInlineShapes & supportFields]><span
style='mso-element:field-begin;mso-field-lock:yes'></span><span
style='mso-spacerun:yes'>�</span>SHAPE<span style='mso-spacerun:yes'>�
</span>\* MERGEFORMAT <span style='mso-element:field-separator'></span><![endif]--><!--[if gte vml 1]><v:group
 id="_x0000_s1033" editas="canvas" style='width:459pt;height:108pt;
 mso-position-horizontal-relative:char;mso-position-vertical-relative:line'
 coordorigin="1260,2552" coordsize="9180,2160">
 <o:lock v:ext="edit" aspectratio="t"/>
 <v:shape id="_x0000_s1032" type="#_x0000_t75" style='position:absolute;left:1260;
  top:2552;width:9180;height:2160' o:preferrelative="f">
  <v:fill o:detectmouseclick="t"/>
  <v:path o:extrusionok="t" o:connecttype="none"/>
  <o:lock v:ext="edit" text="t"/>
 </v:shape><v:shapetype id="_x0000_t6" coordsize="21600,21600" o:spt="6"
  path="m,l,21600r21600,xe">
  <v:stroke joinstyle="miter"/>
  <v:path gradientshapeok="t" o:connecttype="custom" o:connectlocs="0,0;0,10800;0,21600;10800,21600;21600,21600;10800,10800"
   textboxrect="1800,12600,12600,19800"/>
 </v:shapetype><v:shape id="_x0000_s1034" type="#_x0000_t6" style='position:absolute;
  left:1620;top:3272;width:2338;height:900;flip:x'/>
 <v:shape id="_x0000_s1035" type="#_x0000_t6" style='position:absolute;left:4710;
  top:3272;width:3016;height:900;flip:x'/>
 <v:shape id="_x0000_s1036" type="#_x0000_t6" style='position:absolute;left:8460;
  top:3272;width:1439;height:900;flip:x'/>
 <v:line id="_x0000_s1037" style='position:absolute;flip:y' from="1545,3062"
  to="3959,4022">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:line id="_x0000_s1038" style='position:absolute;flip:y' from="4666,3075"
  to="7740,4020">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:line id="_x0000_s1039" style='position:absolute;flip:y' from="8430,3122"
  to="9869,4022">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:line id="_x0000_s1043" style='position:absolute' from="4125,3270"
  to="4125,4200">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:shape id="_x0000_s1044" type="#_x0000_t202" style='position:absolute;
  left:2505;top:3405;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>4 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1045" type="#_x0000_t202" style='position:absolute;
  left:6075;top:3375;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>5 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1046" type="#_x0000_t202" style='position:absolute;
  left:8940;top:3435;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>3 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1047" type="#_x0000_t202" style='position:absolute;
  left:3990;top:3615;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>1 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:line id="_x0000_s1049" style='position:absolute' from="7890,3285"
  to="7891,4215">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:shape id="_x0000_s1050" type="#_x0000_t202" style='position:absolute;
  left:7755;top:3630;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>1 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:line id="_x0000_s1051" style='position:absolute' from="10065,3300"
  to="10066,4230">
  <v:stroke startarrow="block" endarrow="block"/>
 </v:line><v:shape id="_x0000_s1052" type="#_x0000_t202" style='position:absolute;
  left:9930;top:3645;width:420;height:255' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><span style='font-size:10.0pt'>1 m<o:p></o:p></span></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1053" type="#_x0000_t202" style='position:absolute;
  left:2040;top:2700;width:1170;height:345' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal align=center style='text-align:center'>Ramp X<o:p></o:p></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1054" type="#_x0000_t202" style='position:absolute;
  left:5565;top:2700;width:1170;height:345' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal align=center style='text-align:center'>Ramp Y<o:p></o:p></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1055" type="#_x0000_t202" style='position:absolute;
  left:8685;top:2655;width:1170;height:345' stroked="f">
  <v:textbox inset="0,0,0,0">
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal align=center style='text-align:center'>Ramp Z<o:p></o:p></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><w:wrap type="none"/>
 <w:anchorlock/>
</v:group><![endif]--><![if !vml]><img width=612 height=144
src="pretest_files/image005.gif" v:shapes="_x0000_s1033 _x0000_s1032 _x0000_s1034 _x0000_s1035 _x0000_s1036 _x0000_s1037 _x0000_s1038 _x0000_s1039 _x0000_s1043 _x0000_s1044 _x0000_s1045 _x0000_s1046 _x0000_s1047 _x0000_s1049 _x0000_s1050 _x0000_s1051 _x0000_s1052 _x0000_s1053 _x0000_s1054 _x0000_s1055"><![endif]><!--[if mso & !supportInlineShapes & supportFields]><v:shape
 id="_x0000_i1549" type="#_x0000_t75" style='width:459pt;height:108pt'>
 <v:imagedata croptop="-65520f" cropbottom="65520f"/>
</v:shape><span style='mso-element:field-end'></span><![endif]--></p>

<p style='text-align:justify'><INPUT TYPE="radio" NAME="Q11" VALUE="1">X <br>
<INPUT TYPE="radio" NAME="Q11" VALUE="2">Y <br>
<INPUT TYPE="radio" NAME="Q11" VALUE="3">Z <br>
<INPUT TYPE="radio" NAME="Q11" VALUE="4">All are the same </p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

    <p style='text-align:justify'>12. When you turn a screw into a piece of wood, 
      the wood provides the�</p>

<p><INPUT TYPE="radio" NAME="Q12" VALUE="1">effort <br>
<INPUT TYPE="radio" NAME="Q12" VALUE="2">work <br>
<INPUT TYPE="radio" NAME="Q12" VALUE="3">power <br>
<INPUT TYPE="radio" NAME="Q12" VALUE="4">load</p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
</span>

    <p style='text-align:justify'>13a. Which of the following pulley set ups requires 
      the less effort to lift a load?</p>

<p style='text-align:justify'><!--[if supportFields]><span style='mso-element:
field-begin;mso-field-lock:yes'></span><span
style='mso-spacerun:yes'>�</span>SHAPE<span style='mso-spacerun:yes'>�
</span>\* MERGEFORMAT <span style='mso-element:field-separator'></span><![endif]--><!--[if gte vml 1]><v:shape
 id="_x0000_i1553" type="#_x0000_t75" style='width:.05pt;height:.05pt'/><![endif]--><!--[if supportFields]><span
style='mso-element:field-end'></span><![endif]--><!--[if gte vml 1]><v:shape
 id="_x0000_i1556" type="#_x0000_t75" style='width:216.75pt;height:153.75pt'
 o:ole="">
 <v:imagedata src="pretest_files/image006.png" o:title=""/>
</v:shape><![endif]--><![if !vml]><img width=289 height=205
src="pretest_files/image007.jpg" v:shapes="_x0000_i1556"><![endif]><!--[if gte mso 9]><xml>
 <o:OLEObject Type="Embed" ProgID="PhotoDraw.Document.2" ShapeID="_x0000_i1556"
  DrawAspect="Content" ObjectID="_1185709895">
 </o:OLEObject>
</xml><![endif]--></p>

<p><INPUT TYPE="radio" NAME="Q13a" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q13a" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q13a" VALUE="3">A and B require equal force. <br>
<INPUT TYPE="radio" NAME="Q13a" VALUE="4">Not enough information</p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

    <p style='text-align:justify'>13b. Explain your reasoning.</p>

<p style='text-align:justify'><TEXTAREA ROWS="10" COLS="108" WRAP="VIRTUAL" NAME="Q13b"></TEXTAREA></p>

<p style='text-align:justify'><o:p>&nbsp;</o:p></p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
</span>

    <p style='text-align:justify'>14. You can increase the mechanical advantage of 
      a wheel and axle by�</p>

<p><INPUT TYPE="radio" NAME="Q14" VALUE="1">increasing the size of the wheel <br>
<INPUT TYPE="radio" NAME="Q14" VALUE="2">increasing the size of the axle <br>
<INPUT TYPE="radio" NAME="Q14" VALUE="3">increasing both the size of the wheel
and the axle <br>
<INPUT TYPE="radio" NAME="Q14" VALUE="4">decreasing the size of the wheel</p>

<p><o:p>&nbsp;</o:p></p>

    <p style='text-align:justify'>15. In which situation would it take less effort to lift the same ball 
      up to the top of the ramp?</p>

<p style='text-align:justify'><!--[if mso & !supportInlineShapes & supportFields]><span
style='mso-element:field-begin;mso-field-lock:yes'></span><span
style='mso-spacerun:yes'>�</span>SHAPE<span style='mso-spacerun:yes'>�
</span>\* MERGEFORMAT <span style='mso-element:field-separator'></span><![endif]--><!--[if gte vml 1]><v:group
 id="_x0000_s1068" editas="canvas" style='width:459pt;height:109.3pt;
 mso-position-horizontal-relative:char;mso-position-vertical-relative:line'
 coordorigin="1260,9150" coordsize="9180,2186">
 <o:lock v:ext="edit" aspectratio="t"/>
 <v:shape id="_x0000_s1067" type="#_x0000_t75" style='position:absolute;left:1260;
  top:9150;width:9180;height:2186' o:preferrelative="f">
  <v:fill o:detectmouseclick="t"/>
  <v:path o:extrusionok="t" o:connecttype="none"/>
  <o:lock v:ext="edit" text="t"/>
 </v:shape><v:shape id="_x0000_s1069" type="#_x0000_t6" style='position:absolute;
  left:1696;top:9510;width:5084;height:1635' filled="f"/>
 <v:shape id="_x0000_s1070" type="#_x0000_t6" style='position:absolute;left:7442;
  top:9466;width:2278;height:1634' filled="f"/>
 <v:oval id="_x0000_s1075" style='position:absolute;left:6615;top:10694;
  width:434;height:437' o:regroupid="3" fillcolor="silver"/>
 <v:shape id="_x0000_s1080" type="#_x0000_t202" style='position:absolute;
  left:1530;top:9165;width:810;height:435' filled="f" stroked="f">
  <v:textbox style='mso-next-textbox:#_x0000_s1080'>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><b style='mso-bidi-font-weight:normal'>Top <o:p></o:p></b></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:oval id="_x0000_s1101" style='position:absolute;left:9585;top:10674;
  width:434;height:437' fillcolor="silver"/>
 <v:shape id="_x0000_s1102" type="#_x0000_t202" style='position:absolute;
  left:7410;top:9150;width:810;height:435' filled="f" stroked="f">
  <v:textbox style='mso-next-textbox:#_x0000_s1102'>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><b style='mso-bidi-font-weight:normal'>Top <o:p></o:p></b></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><w:wrap type="none"/>
 <w:anchorlock/>
</v:group><![endif]--><![if !vml]><img width=612 height=148
src="pretest_files/image008.gif" v:shapes="_x0000_s1068 _x0000_s1067 _x0000_s1069 _x0000_s1070 _x0000_s1075 _x0000_s1080 _x0000_s1101 _x0000_s1102"><![endif]><!--[if mso & !supportInlineShapes & supportFields]><v:shape
 id="_x0000_i1550" type="#_x0000_t75" style='width:459pt;height:109.3pt'>
 <v:imagedata croptop="-65520f" cropbottom="65520f"/>
</v:shape><span style='mso-element:field-end'></span><![endif]--></p>

<p><INPUT TYPE="radio" NAME="Q15" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q15" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q15" VALUE="3">A and B require equal effort<br>
<INPUT TYPE="radio" NAME="Q15" VALUE="4">Not enough information</p>

<span style='font-size:12.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US;mso-fareast-language:EN-US;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
</span>

    <p>16. The mechanical advantage of a pulley system can be increased by�</p>

<p><INPUT TYPE="radio" NAME="Q16" VALUE="1">exerting an effort force over a
shorter distance<br>
<INPUT TYPE="radio" NAME="Q16" VALUE="2">increasing the effort <br>
<INPUT TYPE="radio" NAME="Q16" VALUE="3">increasing the number of pulleys<br>
<INPUT TYPE="radio" NAME="Q16" VALUE="4">increasing the amount of rope</p>

<p><o:p>&nbsp;</o:p></p>

    <p>17. In which situation would it take less effort to lift the same block 
      using a wheel and axle?</p>

<p><!--[if mso & !supportInlineShapes & supportFields]><span style='mso-element:
field-begin;mso-field-lock:yes'></span><span
style='mso-spacerun:yes'>�</span>SHAPE<span style='mso-spacerun:yes'>�
</span>\* MERGEFORMAT <span style='mso-element:field-separator'></span><![endif]--><!--[if gte vml 1]><v:group
 id="_x0000_s1082" editas="canvas" style='width:459pt;height:228.9pt;
 mso-position-horizontal-relative:char;mso-position-vertical-relative:line'
 coordorigin="1260,5036" coordsize="9180,4578">
 <o:lock v:ext="edit" aspectratio="t"/>
 <v:shape id="_x0000_s1081" type="#_x0000_t75" style='position:absolute;left:1260;
  top:5036;width:9180;height:4578' o:preferrelative="f">
  <v:fill o:detectmouseclick="t"/>
  <v:path o:extrusionok="t" o:connecttype="none"/>
  <o:lock v:ext="edit" text="t"/>
 </v:shape><v:shape id="_x0000_s1100" type="#_x0000_t202" style='position:absolute;
  left:6480;top:5925;width:1200;height:840' filled="f" stroked="f">
  <v:textbox>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><v:shape id="_x0000_i1557" type="#_x0000_t75" style='width:35.25pt;
      height:28.5pt'>
      <v:imagedata src="pretest_files/image009.png" o:title=""/>
     </v:shape></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:shape id="_x0000_s1098" type="#_x0000_t202" style='position:absolute;
  left:3675;top:5340;width:1200;height:840' filled="f" stroked="f">
  <v:textbox>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal><v:shape id="_x0000_i1558" type="#_x0000_t75" style='width:35.25pt;
      height:28.5pt'>
      <v:imagedata src="pretest_files/image009.png" o:title=""/>
     </v:shape></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:group id="_x0000_s1088" style='position:absolute;left:2896;top:5581;
  width:1619;height:3284' coordorigin="2821,5521" coordsize="1619,3284">
  <v:oval id="_x0000_s1083" style='position:absolute;left:2821;top:5521;
   width:1619;height:1619' fillcolor="silver"/>
  <v:oval id="_x0000_s1084" style='position:absolute;left:3428;top:6127;
   width:405;height:406' fillcolor="#333"/>
  <v:line id="_x0000_s1086" style='position:absolute' from="3825,6300" to="3826,8295"/>
  <v:rect id="_x0000_s1087" style='position:absolute;left:3510;top:8250;
   width:630;height:555' fillcolor="#333">
   <v:fill src="pretest_files/image001.gif" o:title="Light downward diagonal"
    type="pattern"/>
  </v:rect></v:group><v:shape id="_x0000_s1096" type="#_x0000_t202" style='position:absolute;
  left:3585;top:8964;width:630;height:450' filled="f" stroked="f">
  <v:textbox>
   <![if !mso]>
   <table cellpadding=0 cellspacing=0 width="100%">
    <tr>
     <td><![endif]>
     <div>
     <p class=MsoNormal align=center style='text-align:center'><b
     style='mso-bidi-font-weight:normal'><span style='font-size:16.0pt'>A<o:p></o:p></span></b></p>
     </div>
     <![if !mso]></td>
    </tr>
   </table>
   <![endif]></v:textbox>
 </v:shape><v:group id="_x0000_s1099" style='position:absolute;left:6510;top:6180;
  width:705;height:3174' coordorigin="6435,5685" coordsize="705,3174">
  <v:oval id="_x0000_s1091" style='position:absolute;left:6435;top:5685;
   width:405;height:406' o:regroupid="2" fillcolor="#969696"/>
  <v:line id="_x0000_s1092" style='position:absolute' from="6840,5865" to="6841,7860"
   o:regroupid="2"/>
  <v:rect id="_x0000_s1093" style='position:absolute;left:6510;top:7815;
   width:630;height:555' o:regroupid="2" fillcolor="#333">
   <v:fill src="pretest_files/image001.gif" o:title="Light downward diagonal"
    type="pattern"/>
  </v:rect><v:shape id="_x0000_s1097" type="#_x0000_t202" style='position:absolute;
   left:6510;top:8409;width:630;height:450' filled="f" stroked="f">
   <v:textbox>
    <![if !mso]>
    <table cellpadding=0 cellspacing=0 width="100%">
     <tr>
      <td><![endif]>
      <div>
      <p class=MsoNormal align=center style='text-align:center'><b
      style='mso-bidi-font-weight:normal'><span style='font-size:16.0pt'>B<o:p></o:p></span></b></p>
      </div>
      <![if !mso]></td>
     </tr>
    </table>
    <![endif]></v:textbox>
  </v:shape></v:group><w:wrap type="none"/>
 <w:anchorlock/>
</v:group><![endif]--><![if !vml]><img width=612 height=305
src="pretest_files/image010.gif" v:shapes="_x0000_s1082 _x0000_s1081 _x0000_s1100 _x0000_s1098 _x0000_s1088 _x0000_s1083 _x0000_s1084 _x0000_s1086 _x0000_s1087 _x0000_s1096 _x0000_s1099 _x0000_s1091 _x0000_s1092 _x0000_s1093 _x0000_s1097"><![endif]><!--[if mso & !supportInlineShapes & supportFields]><v:shape
 id="_x0000_i1551" type="#_x0000_t75" style='width:459pt;height:228.9pt'>
 <v:imagedata croptop="-65520f" cropbottom="65520f"/>
</v:shape><span style='mso-element:field-end'></span><![endif]--></p>

<p><INPUT TYPE="radio" NAME="Q17" VALUE="1">A <br>
<INPUT TYPE="radio" NAME="Q17" VALUE="2">B <br>
<INPUT TYPE="radio" NAME="Q17" VALUE="3">A and B require equal effort<br>
<INPUT TYPE="radio" NAME="Q17" VALUE="4">Not enough information</p>

<p><o:p>&nbsp;</o:p></p>

<p><o:p>&nbsp;</o:p></p>

    <p align=center style='text-align:center'> 
      <INPUT TYPE="submit" NAME="Submit">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <INPUT TYPE="reset" NAME="Reset">
    </p>

</form>

</div>

</body>

</html>
